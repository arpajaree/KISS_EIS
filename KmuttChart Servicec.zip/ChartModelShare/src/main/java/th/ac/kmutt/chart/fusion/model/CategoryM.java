package th.ac.kmutt.chart.fusion.model;

import java.io.Serializable;

/**
 * Created by imake on 21/10/2015.
 */
public class CategoryM implements Serializable{
private String label;

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }
}
