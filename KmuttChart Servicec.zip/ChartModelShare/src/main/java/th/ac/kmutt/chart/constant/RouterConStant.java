package th.ac.kmutt.chart.constant;

public class RouterConStant {
    public static final String USER_ENDPOINT = "userProfile";

}
